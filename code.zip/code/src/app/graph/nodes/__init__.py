"""Graph nodes package."""
